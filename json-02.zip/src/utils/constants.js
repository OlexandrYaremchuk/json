export const api_options = {
  news: {
    key: "f4c510f431ed49698ddbee822a26d381",
    url: "https://newsapi.org/v2/everything?",
  },
};
