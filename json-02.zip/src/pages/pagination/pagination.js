import "../../style/css/main.css";
import "../../style/css/common.css";

import "../../utils/add_header.js";
import { api_options } from "../../utils/constants";

const { key, url } = api_options.news;

const optinons = {
  headers: {
    Autorization: key,
  },
};
